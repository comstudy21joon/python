fp = open("io_test.txt", "w")

fp.close()