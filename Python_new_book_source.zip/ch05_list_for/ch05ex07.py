# Tuple 자료구조 예제
tup01 = (100,200,300,"오징어","꼴뚜기","대구","명태")
#tup01[1] = 1000
print(tup01);

i = 0
while i<len(tup01) :
    print(tup01[i], end=" ")
    i += 1