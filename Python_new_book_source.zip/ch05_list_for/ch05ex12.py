# enumerate() 함수 활용
lis = ["오징어","꼴뚜기","대구","명태","거북이"]

for index, fish in  enumerate(lis):
    print(index, fish)