dic = {}
print(type(dic))

dic["name"] = "홍길동"
dic["phone"] = "010-7777-8888"
dic["addr"] = "응평구 응암동"

print(dict)
print("Name => " + dic["name"])
print("Phone => " + dic["phone"])
print("Addr => " + dic["addr"])