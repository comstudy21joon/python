dict1 = {"name":"홍길동","phone":"010-1234-5678","addr":"서울시 은평구 응암동"}

keys = dict1.keys()
values = dict1.values()

print("keys type :", type(keys))
print("values type :", type(values))

print("keys :", keys)
print("values :", values)