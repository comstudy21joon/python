# sort()함수로 리스트의 내용 정렬
li2 = [9,1,8,7,6,2,5,4,3]
li2.sort()
print(li2)
li2.reverse()
print(li2)