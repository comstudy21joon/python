addrList = [
    {"idx": 0, "name": 'HONG', "phone": '010-111-111', "addr": '서울시'},
    {"idx": 1, "name": 'KIM', "phone": '010-111-111', "addr": '대구시'},
    {"idx": 2, "name": 'LEE', "phone": '010-111-111', "addr": '대전시'}
]

idx = 2;