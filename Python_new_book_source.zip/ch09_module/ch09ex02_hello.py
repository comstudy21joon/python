import ch09ex01_hello as hello
#import ch09_module.ch09ex01_hello as hello

if __name__ == '__main__':
    hello.say_hello("kim")
    hello.say_hello2("hong")