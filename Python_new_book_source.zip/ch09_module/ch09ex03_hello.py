from ch09ex01_hello import say_hello
from ch09ex01_hello import say_hello2


if __name__ == '__main__':
    say_hello("kim")
    say_hello2("hong")