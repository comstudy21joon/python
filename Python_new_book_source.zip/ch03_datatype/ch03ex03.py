'''
2. 인덱싱과 슬라이싱
- print(str1[3] ) 3번째
- print(str1[3:] ) 3번째부터 끝까지
- print(str1[:3] ) 처음부터 3번째까지
- print(str1[-3] ) 뒤에서 부터 3번째
'''

str1 = 'Hello python world'
print(str1[6])
print(str1[6:])
print(str1[:6])
print(str1[-5])