# 파이썬 언어에서 변수 타입은 입력되는 데이터의 타입으로 결정된다
# 변수에는 어떤 타입이든 담을 수 있다.
result = 5 + 3
print(type(result))

result = "HONG"
print(type(result))