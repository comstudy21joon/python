# 변수 var01에  문자열 데이터를 대입하고 값과 타입 확인
var01 = "Korea"
print("value : ", var01)
print("tpe : ",  type(var01))
# 변수 var01에 새로 정수 데이터를 대입하고 값과 타입 확인
var01 = 3000
print("value : ", var01)
print("tpe : ",  type(var01))
# 변수 var01에 다시 새로 실수 데이터를 대입하고 값과 타입 확인
var01 = 3.14
print("value : ", var01)
print("tpe : ",  type(var01))

