import math

# 원주율 상수
pi = math.pi
print("pi =>", pi)

# 자연로그 밑 상수
e = math.e
print("e =>", e)
