# 키보드로 부터 데이터 입력 받기
# input함수는 print가 내포되었다.
user_name = input("사용자 이름 입력 : ")
# 변수에 입력 된 내용 출력
print("사용자 명 :", user_name)
