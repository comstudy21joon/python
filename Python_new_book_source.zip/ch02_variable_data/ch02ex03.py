# 변수의 선언과 동시에 데이터 초기화
name = 'JAVA'
age = 25

# 선언된 변수에 새로운 데이터 입력
name = 'Python'
age = 29

# 변수에 담겨 진 데이터 사용
print('성명은', name, '입니다')
print('나이는', age, '세입니다')
