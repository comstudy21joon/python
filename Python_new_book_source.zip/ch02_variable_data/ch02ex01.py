height = 180
name = "철수"
print(name, "는 키가", height, "센치 입니다.")

# 변수에는 타입과 상관 없이 데이터를 바꿔서 담을 수 있다.
# height변수에는 키 대신 이름을 넣고,
# name 변수에 이름 대신 키를 담아서 사용해도 문제가 되지 않는다.
height = "영희"
name = 170
print(height, "는 키가", name, "센치 입니다.")
