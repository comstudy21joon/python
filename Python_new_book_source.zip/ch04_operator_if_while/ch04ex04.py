# 논리 연산자 예제
isTrue = True and True
print("True and True 의 결과 :", isTrue)
isTrue = True and False
print("True and False 의 결과 :", isTrue)
isTrue = False and True
print("False and True 의 결과 :", isTrue)
isTrue = False and False
print("False and False 의 결과 :", isTrue)
isTrue = True or True
print("True or True 의 결과 :", isTrue)
isTrue = True or False
print("True or False 의 결과 :", isTrue)
isTrue = False or True
print("False or True 의 결과 :", isTrue)
isTrue = False or False
print("False or False 의 결과 :", isTrue)