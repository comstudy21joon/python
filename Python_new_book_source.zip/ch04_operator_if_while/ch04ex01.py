# 산술 연산자 예제
# 변수 초기화
a = 20
# 더하기
result = a + 10
print("더하기 결과:", result)
# 빼기
result = a - 10
print("빼기 결과:", result)
# 곱하기
result = a * 10
print("곱하기 결과:", result)
# 나누기(결과가 실수 형식)
result = a / 3
print("/나누기 결과:", result)
# 나누기(결과가 정수 형식)
result = a // 3
print("//나누기 결과:", result)
# 나머지
result = a % 3
print("나머지 결과:", result)