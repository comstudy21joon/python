# 삼항 연산자 예제
number = 120
result = "100보다 크다" if number>100 else "100 이하이다"
print(result)
# 삼 항 연산자에서 즉시 출력 해 보았다
print("True입니다") if False else print("False입니다")
print("True입니다") if True else print("False입니다")