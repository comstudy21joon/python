# if ~ else문 예제
# 번호를 입력 받아서 홀수 인지 짝수인지 판별
number = int(input("정수 입력 :"))
print("결과 => ", end="")
if number%2==0 :
    print("짝수입니다.")
else :
    print("홀수입니다.")