# 복합 대입 연산자 예제
result = 10
result += 10
print("result += 10 실행 후 결과 : ", result)
result -= 10
print("result -= 10 실행 후 결과 : ", result)
result *= 10
print("result *= 10 실행 후 결과 : ", result)
result //= 10
print("result //= 10 실행 후 결과 : ", result)
result %= 10
print("result %= 10 실행 후 결과 : ", result)