# 비교 연산자를 테스트 할 변수에 초기값 저장
result = 10
isTrue = result == 10
print("result == 10 의 결과 :", isTrue)
isTrue = result > 10
print("result > 10 의 결과 :", isTrue)
isTrue = result < 10
print("result < 10 의 결과 :", isTrue)
isTrue = result >= 10
print("result >= 10 의 결과 :", isTrue)
isTrue = result <= 10
print("result <= 10 의 결과 :", isTrue)
isTrue = result != 10
print("result != 10 의 결과 :", isTrue)