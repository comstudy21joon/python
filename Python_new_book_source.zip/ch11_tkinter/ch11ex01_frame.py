from tkinter import Tk

win = Tk()
#win.geometry("640x400+100+100")
#win.title("TkInterface window")
#win.resizable(False, False)

#win.mainloop()
if __name__ == '__main__':
    win.mainloop()