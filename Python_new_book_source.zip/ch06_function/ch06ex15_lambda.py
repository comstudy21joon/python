# 람다 표션식
# 함다 함수는 익명 함수이다.
'''
lambda 매개변수 : 처리식
'''

# 일반적인 파이썬 함수 선언
def maxinum(x, y) :
    if x > y :
        result = x
    else :
        result = y
        
    return result

# 호출 하기
result = maxinum(10, 20)
print("result => ", result)

