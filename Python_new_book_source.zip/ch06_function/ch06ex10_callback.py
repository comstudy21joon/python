# 콜백함수 예제
def fncA() :
    print("fncA 함수를 실행합니다")


refA = fncA

# refA를 실행하면 fncA 함수가 실행된다.
refA()
