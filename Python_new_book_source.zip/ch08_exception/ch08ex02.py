
try:
    result = 10/0
except ZeroDivisionError as zero :
    print("0으로 나눌 수 없습니다!")
    print(zero)