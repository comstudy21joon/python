import logging

logging.info("INFO log message")
logging.warning("WARNING log message")
logging.debug("Some message")