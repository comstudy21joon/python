
print("Hello" * 30)
print("Hello", "world")
# sep="구분자", end="마침표문자"
# 특수문자 : \n, \r, \a, \t, \b, \\, \", \', \&
print("Hello", "Python", "World", sep="~~", end="----> ")
print("Hello", "Python", "World", sep=" ", end="\n")
